Page({
  data:{
    indicatorDots:true,
    autoplay:true,
    interval:5000,
    duration:1000,
    imgUrls2:["/images/lunbo1.jpeg","/images/lunbo2.jpg","/images/lunbo3.jpg"],
    array:[],
    menu:[{"id":1,"name":"人气推荐"},
          {"id":2,"name":"冬季限定"},
          {"id":3,"name":"果茶系列"},
          {"id":4,"name":"奶芙系列"},
          {"id":5,"name":"抹茶可可"},
          {"id":6,"name":"芝士系列"},
          {"id":7,"name":"纯茶系列"},
          {"id":8,"name":"奶茶家族"},
          {"id":9,"name":"料多多系列"},
          {"id":10,"name":"用餐提醒"}]
  },  //生命周期函数
  onLoad:function(){
    var array2=this.initData()
    this.setData({array:array2})
  },//自定义函数
  //initData:设置页面的初始化数据
  initData:function(){
    var array1=[]
    //定义具体的新闻对象
    var object1=new Object()
    object1.img="/images/dcright/1.jpg"
    object1.title="杨枝甘露椰奶"
    object1.type="含茶"
    object1.liulan="含芒果"
    object1.pinglun="仅做冰饮"
    object1.zw="芒果x西柚粒x西米x多肉x椰奶x茉莉花茶 一口芒果香，才知道是甘露"
    object1.jg="￥17"
    object1.xgg="选规格"
    array1[0]=object1
  
    var object2=new Object()
    object2.img="/images/dcright/2.jpg"
    object2.title="芝士多肉葡萄茉莉"
    object2.type="含茶"
    object2.liulan="含乳制品"
    object2.pinglun="仅做冰饮"
    object2.zw="芝士x多肉x葡萄x茉莉花茶 超多果肉 超满足"
    object2.jg="￥18"
    object2.xgg="选规格"
    array1[1]=object2
  
    var object3=new Object()
    object3.img="/images/dcright/3.jpg"
    object3.title="芋泥青稞牛奶"
    object3.type="新品"
    object3.liulan="含乳制品"
    object3.pinglun=""
    object3.zw="芋泥x芋圆x青稞x牛奶 先蒸芋泥搭配高原青稞，加牛奶的佛系养生"
    object3.jg="￥16"
    object3.xgg="选规格"
    array1[2]=object3
  
    var object4=new Object()
    object4.img="/images/dcright/4.jpeg"
    object4.title="芝士莓莓"
    object4.type="含茶"
    object4.liulan="含乳制品"
    object4.pinglun="仅做冰饮"
    object4.zw="茉莉花茶x鲜草莓x奶盖x多肉 新鲜草莓粒粒严选，暗藏脆弹多肉"
    object4.jg="￥20"
    object4.xgg="选规格"
    array1[3]=object4

    var object5=new Object()
    object5.img="/images/dcright/5.jpg"
    object5.title="大叔奶茶"
    object5.type="含茶"
    object5.liulan=""
    object5.pinglun=""
    object5.zw="古茗奶茶x台湾风味黑糖x红豆x布丁x珍珠 镇店之茶 焦香口感"
    object5.jg="￥11"
    object5.xgg="选规格"
    array1[4]=object5

    var object6=new Object()
    object6.img="/images/dcright/6.jpeg"
    object6.title="酒酿麻薯豆乳茶"
    object6.type="新品"
    object6.liulan="含酒精"
    object6.pinglun="含茶"
    object6.zw="桂花酒酿x麻薯x豆乳奶盖x芋圆x奶绿x桂花酒酿搭配奶香麻薯，豆奶纯香"
    object6.jg="￥15"
    object6.xgg="选规格"
    array1[5]=object6

    var object7=new Object()
    object7.img="/images/dcright/7.jpg"
    object7.title="酒酿麻薯奶绿"
    object7.type="新品"
    object7.liulan="含酒精"
    object7.pinglun="含茶"
    object7.zw="桂花酒酿x麻薯x芋圆x奶绿 桂花酒酿配麻薯，开启冬日新体验"
    object7.jg="￥13"
    object7.xgg="选规格"
    array1[6]=object7

    var object8=new Object()
    object8.img="/images/dcright/8.jpg"
    object8.title="芋泥青稞牛奶"
    object8.type="新品"
    object8.liulan="含乳制品"
    object8.pinglun=""
    object8.zw="芋泥x芋圆x青稞x牛奶 先蒸芋泥搭配高原青稞，加牛奶的佛系养生"
    object8.jg="￥16"
    object8.xgg="选规格"
    array1[7]=object8

    var object9=new Object()
    object9.img="/images/dcright/9.jpeg"
    object9.title="芋泥青稞奶绿"
    object9.type="新品"
    object9.liulan="含茶"
    object9.pinglun=""
    object9.zw="芋泥x芋圆x青稞x奶绿 现蒸芋泥搭配的高原青稞，大颗粒，咀嚼不停歇"
    object9.jg="￥15"
    object9.xgg="选规格"
    array1[8]=object9

    var object10=new Object()
    object10.img="/images/dcright/10.jpeg"
    object10.title="芋泥青稞椰奶"
    object10.type="新品"
    object10.liulan="含椰奶"
    object10.pinglun=""
    object10.zw="芋泥x芋圆x青稞x椰奶 现蒸芋泥搭配高原青稞，浓浓椰香"
    object10.jg="￥16"
    object10.xgg="选规格"
    array1[9]=object10

    var object11=new Object()
    object11.img="/images/dcright/11.jpg"
    object11.title="酷脆贝贝南瓜"
    object11.type="新品"
    object11.liulan="含乳制品"
    object11.pinglun=""
    object11.zw="贝贝南瓜x阿华田酷脆酱x牛乳 浓郁香甜，尽享秋的童话"
    object11.jg="￥16"
    object11.xgg="选规格"
    array1[10]=object11

    var object12=new Object()
    object12.img="/images/dcright/12.jpg"
    object12.title="杨枝甘露轻盈版"
    object12.type="含芒果"
    object12.liulan="含乳制品"
    object12.pinglun="含茶"
    object12.zw="芒果x西柚粒x多肉x椰奶 超值大杯，超清爽"
    object12.jg="￥18"
    object12.xgg="选规格"
    array1[11]=object12

    var object13=new Object()
    object13.img="/images/dcright/13.jpg"
    object13.title="杨枝甘露椰奶"
    object13.type="含茶"
    object13.liulan="含芒果"
    object13.pinglun="仅做冰饮"
    object13.zw="芒果x西柚粒x西米x多肉x椰奶x茉莉花茶 一口芒果，才是真的甘露"
    object13.jg="￥17"
    object13.xgg="选规格"
    array1[12]=object13

    var object14=new Object()
    object14.img="/images/dcright/14.jpg"
    object14.title="晚香一颗柠"
    object14.type="含茶"
    object14.liulan="仅做冰饮"
    object14.zw="一整颗黄柠x晚香红茶 1整颗新鲜黄柠，全新伯爵风味茶底"
    object14.jg="￥13"
    object14.pinglun=""
    object14.xgg="选规格"
    array1[13]=object14

    var object15=new Object()
    object15.img="/images/dcright/15.jpeg"
    object15.title="百香双重奏茉莉"
    object15.type="含茶"
    object15.liulan="仅做冰饮"
    object15.pinglun=""
    object15.zw="茉莉花茶x百香果x青橘x椰果x珍珠 百香清香超多维C 一嚼满口清香"
    object15.jg="￥11"
    object15.xgg="选规格"
    array1[14]=object15

    var object16=new Object()
    object16.img="/images/dcright/16.jpg"
    object16.title="桃气乌龙奶芙"
    object16.type="新品"
    object16.liulan="含茶"
    object16.pinglun="含乳制品"
    object16.zw="牛乳x凤桃乌龙茶x核桃碎x奶油顶 入口蜜桃香，清爽不涩口"
    object16.jg="￥15"
    object16.xgg="选规格"
    array1[15]=object16

    var object17=new Object()
    object17.img="/images/dcright/17.jpeg"
    object17.title="桃气乌龙轻乳"
    object17.type="新品"
    object17.liulan="含乳制品"
    object17.pinglun="含茶"
    object17.zw="牛乳x凤桃乌龙茶x丝滑牛乳，蜜桃香郁"
    object17.jg="￥15"
    object17.xgg="选规格"
    array1[16]=object17

    var object18=new Object()
    object18.img="/images/dcright/18.jpeg"
    object18.title="伯爵鲜奶茶"
    object18.type="含茶"
    object18.liulan="含乳制品"
    object18.pinglun=""
    object18.zw="鲜牛乳x红茶x碧根果碎x奶油顶 首用新牛乳，伯爵风味绵密醇香"
    object18.jg="￥15"
    object18.xgg="选规格"
    array1[17]=object18

    var object19=new Object()
    object19.img="/images/dcright/19.jpeg"
    object19.title="布蕾脆脆奶芙"
    object19.type="含茶"
    object19.liulan="含乳制品"
    object19.pinglun=""
    object19.zw="布蕾x珍珠x碧根果碎x奶油顶 吃一口脆脆，喝一口丝滑"
    object19.jg="￥16"
    object19.xgg="选规格"
    array1[18]=object19

    var object20=new Object()
    object20.img="/images/dcright/20.jpeg"
    object20.title="玄米香抹茶"
    object20.type="含茶"
    object20.liulan="含乳制品"
    object20.pinglun=""
    object20.zw="玄米x抹茶x牛奶 玄米新加入，浓郁抹茶香"
    object20.jg="￥11"
    object20.xgg="选规格"
    array1[19]=object20

    var object21=new Object()
    object21.img="/images/dcright/21.jpg"
    object21.title="满登登抹茶"
    object21.type="含茶"
    object21.liulan="含乳制品"
    object21.pinglun=""
    object21.zw="玄米x抹茶x牛奶x芋圆x青稞x布丁 抹茶加玄米，料多超满足"
    object21.jg="￥14"
    object21.xgg="选规格"
    array1[20]=object21
    return array1
  }
})