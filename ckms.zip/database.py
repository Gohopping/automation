import sqlite3
class Sqlite:
    DB_FILE = 'ckms.db'

    def __init__(self):
        self.conn = sqlite3.connect(Sqlite.DB_FILE)
        self.conn.row_factory = sqlite3.Row
        self.cursor = self.conn.cursor()

    def __del__(self):
        self.cursor.close()
        self.conn.close()