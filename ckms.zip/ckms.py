from flask import Flask, render_template, redirect, request, session, url_for
from database import Sqlite
import os

app = Flask(__name__)
app.secret_key = os.urandom(24) # 设置随机的secret_key

@app.route('/register/', methods=('GET', 'POST'))
def register():
    """
    注册处理
    """
    if request.method == 'GET':
        return render_template('register.html')
    if request.method == 'POST':
        form_data = request.form.to_dict()
        username = form_data.get('username')
        password1 = form_data.get('password1')
        password2 = form_data.get('password2')
        if password1 != password2:
            msg = '密码不一致，注册失败！'
            return render_template('register.html', msg=msg)

        db = Sqlite()
        sql = f"select * from user where username = '{username}'"
        user = db.cursor.execute(sql).fetchone()
        if user:
            msg = '用户名已存在，注册失败！'
            return render_template('register.html', msg=msg)

        try:
            data = (username, password1)
            sql = "insert into user (username, password) values(?,?)"
            db.cursor.execute(sql, data)
            db.conn.commit()
        except:
            msg = '注册失败！'
            return render_template('register.html', msg=msg)
        session['username'] = username
        return redirect(url_for('index'))

@app.route('/login/', methods=('GET', 'POST'))
def login():
    """
    登录处理
    """
    if request.method == 'GET':
        return render_template('login.html')
    if request.method == 'POST':
        form_data = request.form.to_dict()
        username = form_data.get('username')
        password = form_data.get('password')
        db = Sqlite()
        sql = f"""select * from user 
                  where username = '{username}' and 
                  password = '{password}'"""
        user = db.cursor.execute(sql).fetchone()
        if user:
            session['username'] = username
            return redirect(url_for('index'))
        msg = '用户名或密码错误，登录失败！'
        return render_template('login.html', msg=msg)

@app.route('/')
def index():
    """
    首页，直接跳转任务大厅
    """
    return redirect(url_for('page', page_id=0))

@app.route('/logout/')
def logout():
    session.clear()  # 清除该会话所有数据
    return redirect(url_for('login'))

@app.route('/p/')
def page():
    '''
    跳转至选择的处理界面
    :return: index.html
    '''
    return render_template('index.html')

@app.route('/shopping/')
def shopping():
    return render_template('shopping.html')

@app.route('/addshopping/', methods=('GET','POST'))
def addshopping():
    if request.method == 'GET':
        return render_template('addshopping.html')
    if request.method == 'POST':
        form = request.form.to_dict()
        s_id = form.get('s_id')
        s_name = form.get('s_name')
        s_price = form.get('s_price')
        s_amount = form.get('s_amount')
        w_id = form.get('w_id')
        db = Sqlite()
        sql = f"select s_id from shop where s_id = {s_id}"
        row = db.cursor.execute(sql).fetchone()
        if row:
            mag = '商品编号已经存在，添加失败'
            return render_template('addshopping.html', mag=mag)
        else:
            data = (s_id, s_name, s_price, s_amount, w_id)
            sql = "insert into shop(s_id,s_name,s_price,s_amount,w_id) values(?,?,?,?,?)"
            db.cursor.execute(sql, data)
            db.conn.commit()
            msg = '添加成功'
            return render_template('addshopping.html', msg=msg)
    return render_template('addshopping.html')

@app.route('/deletshopping/', methods=('GET','POST'))
def deletshopping():
    if request.method == 'GET':
        return render_template('deletshopping.html')
    if request.method == 'POST':
        form = request.form.to_dict()
        s_id = form.get('s_id')
        db = Sqlite()
        sql = "select * from shop where s_id = {}".format(s_id)
        rows = db.cursor.execute(sql).fetchall()
        if rows:
            for row in rows:
                task = (row['s_id'], row['s_name'], row['s_price'], row['s_amount'], row['w_id'])
            sql = f"delete from shop where  s_id ={s_id} "
            db.cursor.execute(sql)
            db.conn.commit()
            msg = '删除成功'
            return render_template('deletshopping.html', msg=msg, task=task)
        else:
            mag = '删除失败'
            return render_template('deletshopping.html', mag=mag)
    return render_template('deletshopping.html')

@app.route('/warehouse/')
def warehouse():
    return render_template('warehouse.html')

@app.route('/addwarehouse/', methods=('GET','POST'))
def addwarehouse():
    if request.method == 'GET':
        return render_template('addwarehouse.html')
    if request.method == 'POST':
        form = request.form.to_dict()
        w_id = form.get('w_id')
        w_name = form.get('w_name')
        w_cap = form.get('w_cap')
        w_nature = form.get('w_nature')
        db = Sqlite()
        sql = f"select w_id from warehouse where w_id = {w_id}"
        row = db.cursor.execute(sql).fetchone()
        if row:
            mag = '添加失败'
            return render_template('addwarehouse.html', mag=mag)
        else:
            data = (w_id, w_name, w_cap, w_nature)
            sql = "insert into warehouse(w_id,w_name,w_cap,w_nature) values(?,?,?,?)"
            db.cursor.execute(sql, data)
            db.conn.commit()
            msg = '添加成功'
            return render_template('addwarehouse.html', msg=msg)
    return render_template('addwarehouse.html')

@app.route('/updatewarehouse/', methods=('GET','POST'))
def updatewarehouse():
    if request.method == 'GET':
        return render_template('updatewarehouse.html')
    if request.method == 'POST':
        form = request.form.to_dict()
        w_id = form.get('w_id')
        w_name = form.get('w_name')
        w_cap = form.get('w_cap')
        w_nature = form.get('w_nature')
        db = Sqlite()
        sql = "select * from warehouse where w_id = {} ".format(w_id)
        rows = db.cursor.execute(sql).fetchall()
        if rows:
            sql = "update warehouse set w_id={}, w_name='{}', w_cap={}, w_nature='{}' where w_id={} ".format(w_id, w_name, w_cap, w_nature, w_id)
            db.cursor.execute(sql)
            db.conn.commit()
            msg = '成功'
            sql = f"select * from warehouse where w_id={w_id}"
            rows = db.cursor.execute(sql).fetchall()
            for row in rows:
                wup = (row['w_id'], row['w_name'], row['w_cap'], row['w_nature'])
            return render_template('updatewarehouse.html', wup=wup, msg=msg)
        else:
            mag = '失败'
            return render_template('updatewarehouse.html', mag=mag)
    return render_template('updatewarehouse.html')

@app.route('/deletwarehouse/', methods=('GET','POST'))
def deletwarehouse():
    if request.method == 'GET':
        return render_template('deletwarehouse.html')
    if request.method == 'POST':
        form = request.form.to_dict()
        w_id = form.get('w_id')
        db = Sqlite()
        sql = f"select w_id from warehouse where w_id = {w_id}"
        row = db.cursor.execute(sql).fetchone()
        if row:
            sql = f"delete from warehouse where  w_id = {w_id} "
            db.cursor.execute(sql)
            db.conn.commit()
            msg = '删除成功'
            return render_template('deletwarehouse.html', msg=msg)
        else:
            mag = '删除失败'
            return render_template('deletwarehouse.html', mag=mag)
    return render_template('deletwarehouse.html')

@app.route('/stateshop/')
def stateshop():
    db = Sqlite()
    sql = "select * from shop"
    rows = db.cursor.execute(sql).fetchall()
    if rows:
        task = []
        for row in rows:
            task.append((row['s_id'], row['s_name'], row['s_price'], row['s_amount'], row['w_id']))
    return render_template('stateshop.html', tasks=task)

@app.route('/stateware')
def stateware():
    db = Sqlite()
    sql = "select * from warehouse"
    rows = db.cursor.execute(sql).fetchall()
    if rows:
        ss = []
        for row in rows:
            ss.append((row['w_id'], row['w_name'], row['w_cap'], row['w_nature']))
    return render_template('stateware.html', sss=ss)

@app.before_request
def access_filter():
    """
    除了注册、登录、及静态文件请求，其余路径都需登录才可访问
    :return: None or Response
    """
    if 'username' not in session:
        access_able = request.path in [url_for('login'), url_for('register')]\
            or request.path.startswith('/static/')
        if not access_able:
            return redirect(url_for('login'))


@app.template_global()
def get_user():
    '''
    获取用户数据的方法，供模板和视图使用
    :return: dict
    '''
    username = session.get('username')
    if not username:
        return None
    user = session.get('user')
    if user:
        return user
    db = Sqlite()
    sql = f"select * from user where username = '{username}'"
    user = db.cursor.execute(sql).fetchone()
    session['user'] = dict(user)
    return user

if __name__ == '__main__':
    app.run(debug=True)

