from flask import Flask,render_template, redirect, request, session, url_for
import csv
from database import Sqlite
import pandas as pd

BYSJ=Flask(__name__)

@BYSJ.route('/')
def hello_world():
    return render_template('start.html')

@BYSJ.route('/Comprehensive_hot_form')#综合热门必刷表单
def Comprehensive_hot_form():
    #读取爬取到的数据
    data=[] #把读取的数据用列表存储起来
    db = Sqlite()
    sql = "select * from zhrm"
    zhrm_data=db.cursor.execute(sql)
    for i in zhrm_data:
        data.append(i)
    db.conn.commit()
    return render_template('Comprehensive_hot_form.html',alldata=data)#把数据传进demo.html中

@BYSJ.route('/Comprehensive_hot_chart')#综合热门可视化大屏
def Comprehensive_hot_chart():
    #读取爬取到的数据
    zhrm_title = [] #把读取的数据用列表存储起来
    zhrm_name = []
    zhrm_view = []
    zhrm_damaku = []
    zhrm_damaku_topten = []
    Up_data_topten = []
    zhrm_pie = []
    db = Sqlite()
    sql = "select * from zhrm"
    zhrm_data = db.cursor.execute(sql)
    for i in zhrm_data:
        zhrm_title.append(i['zhrm_title'])
        zhrm_name.append(i['zhrm_name'])
        zhrm_view.append(i['zhrm_view'])
        zhrm_damaku.append(i['zhrm_damaku'])
    db.conn.commit()
    df = pd.DataFrame({"弹幕量": zhrm_damaku, "Up主": zhrm_name})
    df = df.sort_values(by='弹幕量', ascending=False)
    damaku_data = df['弹幕量'].values
    Up_data = df["Up主"]
    for i in damaku_data:
        zhrm_damaku_topten.append(i)
    for i in Up_data:
        Up_data_topten.append(i)
    for i in range(10):
         zhrm_pie.append({'value': str(zhrm_damaku_topten[i]),'name':str(Up_data_topten[i])})
    return render_template('Comprehensive_hot_chart.html',title=zhrm_title,view=zhrm_view,damaku=zhrm_damaku,up=zhrm_name,zhrm_pie=zhrm_pie)

@BYSJ.route('/Inbound_required_form')#入站必刷表单
def Inbound_required_form():
    #读取爬取到的数据
    data=[] #把读取的数据用列表存储起来
    db = Sqlite()
    sql = "select * from rzbs"
    zhrm_data=db.cursor.execute(sql)
    for i in zhrm_data:
        data.append(i)
    db.conn.commit()
    return render_template('Inbound_required_form.html',alldata=data)#把数据传进demo.html中

@BYSJ.route('/Inbound_required_chart')#入站必刷可视化大屏
def Inbound_required_chart():
    #读取爬取到的数据
    rzbs_title = [] #把读取的数据用列表存储起来
    rzbs_name = []
    rzbs_view = []
    rzbs_damaku = []
    rzbs_damaku_topten = []
    Up_data_topten = []
    rzbs_pie = []
    db = Sqlite()
    sql = "select * from rzbs"
    zhrm_data = db.cursor.execute(sql)
    for i in zhrm_data:
        rzbs_title.append(i['rzbs_title'])
        rzbs_name.append(i['rzbs_name'])
        rzbs_view.append(i['rzbs_view'])
        rzbs_damaku.append(i['rzbs_damaku'])
    db.conn.commit()
    df = pd.DataFrame({"弹幕量": rzbs_damaku, "Up主": rzbs_name})
    df = df.sort_values(by='弹幕量', ascending=False)
    damaku_data = df['弹幕量'].values
    Up_data = df["Up主"]
    for i in damaku_data:
        rzbs_damaku_topten.append(i)
    for i in Up_data:
        Up_data_topten.append(i)
    for i in range(10):
         rzbs_pie.append({'value': str(rzbs_damaku_topten[i]),'name':str(Up_data_topten[i])})
    return render_template('Inbound_required_chart.html',title=rzbs_title,view=rzbs_view,damaku=rzbs_damaku,up=rzbs_name,rzbs_pie=rzbs_pie)

@BYSJ.route('/Must_see_everyweek_form')#每周必看表单
def Must_see_everyweek_form():
    #读取爬取到的数据
    data=[] #把读取的数据用列表存储起来
    db = Sqlite()
    sql = "select * from mzbk"
    zhrm_data=db.cursor.execute(sql)
    for i in zhrm_data:
        data.append(i)
    db.conn.commit()
    return render_template('Must_see_everyweek_form.html',alldata=data)#把数据传进demo.html中

@BYSJ.route('/Must_see_everyweek_chart')#每周必看可视化大屏
def Must_see_everyweek_chart():
    #读取爬取到的数据
    mzbk_title = [] #把读取的数据用列表存储起来
    mzbk_name = []
    mzbk_view = []
    mzbk_damaku = []
    mzbk_retitle = []
    mzbk_damaku_topten = []
    Up_data_topten = []
    mzbk_pie = []
    db = Sqlite()
    sql = "select * from mzbk"
    zhrm_data = db.cursor.execute(sql)
    for i in zhrm_data:
        mzbk_title.append(i['mzbk_title'])
        mzbk_name.append(i['mzbk_name'])
        mzbk_view.append(i['mzbk_view'])
        mzbk_damaku.append(i['mzbk_damaku'])
        mzbk_retitle.append(i['mzbk_rmtitle'])
    db.conn.commit()
    df = pd.DataFrame({"弹幕量": mzbk_damaku, "Up主": mzbk_name})
    df = df.sort_values(by='弹幕量', ascending=False)
    damaku_data = df['弹幕量'].values
    Up_data = df["Up主"]
    for i in damaku_data:
        mzbk_damaku_topten.append(i)
    for i in Up_data:
        Up_data_topten.append(i)
    for i in range(10):
         mzbk_pie.append({'value': str(mzbk_damaku_topten[i]),'name':str(Up_data_topten[i])})
    return render_template('Must_see_everyweek_chart.html',title=mzbk_title,view=mzbk_view,damaku=mzbk_damaku,up=mzbk_name,mzbk_pie=mzbk_pie)

@BYSJ.route('/Ranking_list_form')#排行榜表单
def Ranking_list_form():
    #读取爬取到的数据
    data=[] #把读取的数据用列表存储起来
    db = Sqlite()
    sql = "select * from phb"
    zhrm_data=db.cursor.execute(sql)
    for i in zhrm_data:
        data.append(i)
    db.conn.commit()
    return render_template('Ranking_list_form.html',alldata=data)#把数据传进demo.html中

@BYSJ.route('/Ranking_list_chart')#排行榜可视化大屏
def Ranking_list_chart():
    #读取爬取到的数据
    phb_title = [] #把读取的数据用列表存储起来
    phb_name = []
    phb_view = []
    phb_damaku = []
    phb_retitle = []
    phb_damaku_topten = []
    Up_data_topten = []
    phb_pie = []
    db = Sqlite()
    sql = "select * from phb"
    zhrm_data = db.cursor.execute(sql)
    for i in zhrm_data:
        phb_title.append(i['phb_title'])
        phb_name.append(i['phb_name'])
        phb_view.append(i['phb_view'])
        phb_damaku.append(i['phb_damaku'])
    db.conn.commit()
    df = pd.DataFrame({"弹幕量": phb_damaku, "Up主": phb_name})
    df = df.sort_values(by='弹幕量', ascending=False)
    damaku_data = df['弹幕量'].values
    Up_data = df["Up主"]
    for i in damaku_data:
        phb_damaku_topten.append(i)
    for i in Up_data:
        Up_data_topten.append(i)
    for i in range(10):
         phb_pie.append({'value': str(phb_damaku_topten[i]),'name':str(Up_data_topten[i])})
    return render_template('Ranking_list_chart.html',title=phb_title,view=phb_view,damaku=phb_damaku,up=phb_name,phb_pie=phb_pie)

@BYSJ.route('/Channel_form')#热门频道表单
def Channel_form():
    #读取爬取到的数据
    data=[] #把读取的数据用列表存储起来
    db = Sqlite()
    sql = "select * from rmpd"
    zhrm_data=db.cursor.execute(sql)
    for i in zhrm_data:
        data.append(i)
    db.conn.commit()
    return render_template('Channel_form.html',alldata=data)#把数据传进demo.html中

@BYSJ.route('/Channel_chart')#热门频道可视化大屏
def Channel_chart():
    #读取爬取到的数据
    rmpd_kind = [] #把读取的数据用列表存储起来
    rmpd_vt = []
    rmpd_fv = []
    rmpd_view = []
    rmpd_subscribe = []
    rmpd_subscribe_topten = []
    rmpd_kind_topten = []
    rmpd_pie = []
    db = Sqlite()
    sql = "select * from rmpd"
    zhrm_data = db.cursor.execute(sql)
    for i in zhrm_data:
        rmpd_kind.append(i['rmpd_kind'])
        rmpd_vt.append(i['rmpd_vt'])
        rmpd_fv.append(i['rmpd_fv'])
        rmpd_view.append(i['rmpd_view'])
        rmpd_subscribe.append(i['rmpd_subscribe'])
    db.conn.commit()
    df = pd.DataFrame({"订阅量": rmpd_subscribe, "视频类型": rmpd_kind})
    df = df.sort_values(by='订阅量', ascending=False)
    rmpd_subscribe_data = df['订阅量'].values
    rmpd_kind_data = df["视频类型"]
    for i in rmpd_subscribe_data:
        rmpd_subscribe_topten.append(i)
    for i in rmpd_kind_data:
        rmpd_kind_topten.append(i)
    for i in range(10):
         rmpd_pie.append({'value': str(rmpd_subscribe_topten[i]),'name':str(rmpd_kind_topten[i])})
    return render_template('Channel_chart.html',title=rmpd_kind,view=rmpd_vt,damaku=rmpd_fv,up=rmpd_view,rmpd_pie=rmpd_pie)

if __name__=='__main__':
    BYSJ.run(debug=True)