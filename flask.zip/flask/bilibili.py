import requests
import json
from database import Sqlite
from bs4 import BeautifulSoup
import re

def Get_Comprehensive_hot_data():
    header={
    'user-agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.75 Safari/537.36'
    }
    url='https://api.bilibili.com/x/web-interface/popular'
    for i in range(1,20): #对所有的数据爬取
        param={
            'ps':20,
            'pn':i #第一页数据.共有十一页
        }#把参数封装成字典
        res_zhrm=requests.get(url=url,headers=header,params=param)
        Zhrm_Parse(res_zhrm.text)
        # print(res_zhrm.text)
        res_zhrm.close()

def Zhrm_Parse(text):
    dict = json.loads(text)  # 把数据转化为字典方便数据提取
    # print(dict['data']['list'])
    for i in dict['data']['list']:
        # print(i['title'])#标题
        zhrm_title_J = i['title']
        zhrm_title = zhrm_title_J.replace("\"","\'")
        # print(i['owner']['name'])#Up主
        zhrm_name = i['owner']['name']
        # print(i['stat']['view'])#观看量
        zhrm_view = i['stat']['view']
        # print(i['stat']['danmaku'])#弹幕数
        zhrm_damaku = i['stat']['danmaku']
        db = Sqlite()
        sql = '''select * from zhrm where zhrm_title= "%s" '''%(zhrm_title)
        rows = db.cursor.execute(sql).fetchall()
        if rows:
            sql = 'update zhrm set zhrm_title="{}",zhrm_name="{}",zhrm_view={},zhrm_damaku={} where zhrm_title="{}" '.format(zhrm_title, zhrm_name, zhrm_view, zhrm_damaku, zhrm_title)
            db.cursor.execute(sql)
            db.conn.commit()
        else:
            data = (zhrm_title, zhrm_name, zhrm_view, zhrm_damaku)
            sql = "insert into zhrm(zhrm_title,zhrm_name,zhrm_view,zhrm_damaku) values(?,?,?,?)"
            db.cursor.execute(sql, data)
            db.conn.commit()
            print("zhrm插入成功")
    print("zhrm更新成功")

def Get_Inbound_required_data():  # 获取入站必刷的数据信息
    header = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36'
    }
    url = 'https://api.bilibili.com/x/web-interface/popular/precious'
    param = {
        'page_size': 100,
        'page': 1
    }
    res_rzbs = requests.get(url=url, headers=header, params=param)
    Rzbs_Parse(res_rzbs.text)
    # print(res_rzbs.text)
    res_rzbs.close()

def Rzbs_Parse(text):
    dict = json.loads(text)  # 把数据转化为字典方便数据提取
    # print(dict['data']['list'])
    for i in dict['data']['list']:
        # print(i['title'])#标题
        rzbs_title_J = i['title']
        rzbs_title = rzbs_title_J.replace("\"", "\'")
        # print(i['owner']['name'])#Up主
        rzbs_name = i['owner']['name']
        # print(i['stat']['view'])#观看量
        rzbs_view = i['stat']['view']
        # print(i['stat']['danmaku'])#弹幕数
        rzbs_damaku = i['stat']['danmaku']
        db = Sqlite()
        sql = 'select * from rzbs where rzbs_title= "{}" '.format(rzbs_title)
        rows = db.cursor.execute(sql).fetchall()
        if rows:
            sql = 'update rzbs set rzbs_title="{}",rzbs_name="{}",rzbs_view={},rzbs_damaku={} where rzbs_title="{}"'.format(rzbs_title, rzbs_name, rzbs_view, rzbs_damaku, rzbs_title)
            db.cursor.execute(sql)
            db.conn.commit()
        else:
            data = (rzbs_title, rzbs_name, rzbs_view, rzbs_damaku)
            sql = "insert into rzbs(rzbs_title,rzbs_name,rzbs_view,rzbs_damaku) values(?,?,?,?)"
            db.cursor.execute(sql, data)
            db.conn.commit()
            print("rzbs插入成功")
    print("rzbs更新成功")

def Get_Must_see_everyweek_data():#获取每周必看的数据信息
    header={
    'user-agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36'
    }
    url='https://api.bilibili.com/x/web-interface/popular/series/one'
    param={
        'number':165
    }
    res_mzbk = requests.get(url=url,headers=header,params=param)
    Mzbk_Parse(res_mzbk.text)
    # print(res_mzbk.text)
    res_mzbk.close()

def Mzbk_Parse(text):#对爬取到的每周必看数据，获取每一条视频的标题，Up主, 播放量,观看量，弹幕数，热门标题
    dict = json.loads(text)  # 把数据转化为字典方便数据提取
    # print(dict['data']['list'])
    for i in dict['data']['list']:
        # print(i['title'])#标题
        mzbk_title_J = i['title']
        mzbk_title = mzbk_title_J.replace("\"", "\'")
        # print(i['owner']['name'])#Up主
        mzbk_name = i['owner']['name']
        # print(i['stat']['view'])#观看量
        mzbk_view = i['stat']['view']
        # print(i['stat']['danmaku'])#弹幕数
        mzbk_damaku = i['stat']['danmaku']
        # print(i['rcmd_reason'])#热门标题
        mzbk_rmtitle_J = i['rcmd_reason']
        mzbk_rmtitle = mzbk_rmtitle_J.replace("\"", "\'")
        db = Sqlite()
        sql = 'select * from mzbk where mzbk_title= "%s" '%(mzbk_title)
        rows = db.cursor.execute(sql).fetchall()
        if rows:
            sql = 'update mzbk set mzbk_title="{}",mzbk_name="{}",mzbk_view={},mzbk_damaku={} where mzbk_rmtitle="{}"'.format(mzbk_title, mzbk_name, mzbk_view, mzbk_damaku, mzbk_rmtitle)
            db.cursor.execute(sql)
            db.conn.commit()
        else:
            data = (mzbk_title, mzbk_name, mzbk_view, mzbk_damaku, mzbk_rmtitle)
            sql = "insert into mzbk(mzbk_title,mzbk_name,mzbk_view,mzbk_damaku,mzbk_rmtitle) values(?,?,?,?,?)"
            db.cursor.execute(sql, data)
            db.conn.commit()
            print("mzbk插入成功")
    print("mzbk更新成功")

def Get_Ranking_list_data():#获取排行榜数据信息
    header = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36'
    }
    url = 'https://www.bilibili.com/v/popular/rank/all'
    res_phb = requests.get(url=url, headers=header)
    res_phb_html = res_phb.text
    phb_soup = BeautifulSoup(res_phb_html,'html.parser')
    phb_list = phb_soup.findAll('li',{'class':'rank-item'})
    Phb_Parse(phb_list)
    # print(phb_list)

def Phb_Parse(text):
    for phb in text:
        phb_title_J = phb.find('a', {'class': 'title'}).text#标题
        phb_title = phb_title_J.replace("\"", "\'")
        phb_name = phb.find('span',{'class':'data-box up-name'}).text.replace(" ","").replace("\n","")#Up主
        phb_view_str = phb.find('div',{'class':'detail-state'}).find_all('span')[0].text.replace(" ","").replace("\n","")#观看量
        phb_damaku_str = phb.find('div',{'class':'detail-state'}).find_all('span')[1].text.replace(" ","").replace("\n","")#弹幕数
        phb_view = float(re.sub('[\u4e00-\u9fa5]', '', phb_view_str))
        phb_damaku = float(re.sub('[\u4e00-\u9fa5]', '', phb_damaku_str))
        db = Sqlite()
        sql = 'select * from phb where phb_title= "%s" ' %(phb_title)
        rows = db.cursor.execute(sql).fetchall()
        if rows:
            sql = 'update phb set phb_title="{}",phb_name="{}",phb_view={},phb_damaku={} where phb_title="{}"'.format(phb_title, phb_name, phb_view, phb_damaku,phb_title)
            db.cursor.execute(sql)
            db.conn.commit()
        else:
            data = (phb_title, phb_name, phb_view, phb_damaku)
            sql = "insert into phb(phb_title,phb_name,phb_view,phb_damaku) values(?,?,?,?)"
            db.cursor.execute(sql, data)
            db.conn.commit()
            print("phb插入成功")
    print("phb更新成功")

def Get_Channel_data():#获取频道数据信息
    header = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36'
    }
    url = 'https://api.bilibili.com/x/web-interface/web/channel/category/channel/list'
    param = {
        'id':100,
        'offset':0,
        'page_size':100
    }
    res_pd = requests.get(url=url, headers=header, params=param)
    Pd_Parse(res_pd.text)
    # print(res_pd.text)
    res_pd.close()

def Pd_Parse(text):
    dict = json.loads(text)  # 把数据转化为字典方便数据提取
    # print(dict['data']['list'])
    for i in dict['data']['channels']:
        # print(i['name'])#频道类型
        rmpd_kind_J = i['name']
        rmpd_kind = rmpd_kind_J.replace("\"", "\'")
        # print(i['archive_count'])#视频个数
        rmpd_vt_str = i['archive_count']
        # print(i['featured_count'])#精选个数
        rmpd_fv = i['featured_count']
        # print(i['view_count'])#观看量
        rmpd_view_str = i['view_count']
        # print(i['subscribed_count']#订阅量
        rmpd_subscribe = i['subscribed_count']
        rmpd_vt = float(re.sub('[\u4e00-\u9fa5]', '', rmpd_vt_str))
        rmpd_view = float(re.sub('[\u4e00-\u9fa5]', '', rmpd_view_str))
        db = Sqlite()
        sql = 'select * from rmpd where rmpd_kind= "{}" '.format(rmpd_kind)
        rows = db.cursor.execute(sql).fetchall()
        if rows:
            sql = 'update rmpd set rmpd_kind="{}",rmpd_vt={},rmpd_fv={},rmpd_view={},rmpd_subscribe={} where rmpd_kind="{}"'.format(rmpd_kind, rmpd_vt,rmpd_fv, rmpd_view, rmpd_subscribe, rmpd_kind)
            db.cursor.execute(sql)
            db.conn.commit()
        else:
            data = (rmpd_kind, rmpd_vt, rmpd_fv, rmpd_view, rmpd_subscribe)
            sql = "insert into rmpd(rmpd_kind,rmpd_vt,rmpd_fv,rmpd_view,rmpd_subscribe) values(?,?,?,?,?)"
            db.cursor.execute(sql, data)
            db.conn.commit()
            print("rmpd插入成功")
    print("rmpd更新成功")

if __name__ == '__main__':
    Get_Comprehensive_hot_data()
    Get_Must_see_everyweek_data()
    Get_Inbound_required_data()
    Get_Ranking_list_data()
    Get_Channel_data()