function dealTime(num){
    return num>10? num:'0'+num
}
function getTime(){
    let now = new Date()
    let y = now.getFullYear()
    let t = now.getMonth() + 1
    let d = now.getDate()
    let h = now.getHours()
    let m = now.getMinutes()
    let s = now.getSeconds()
    let text=h>12? 'pm':'am'
    //替换内容 两位数处理
    y = dealTime(y)
    t = dealTime(t)
    d = dealTime(d)
    h = dealTime(h)
    m = dealTime(m)
    s = dealTime(s)
    let result=y+'年'+t+'月'+d+'日'+h+':'+m+':'+s+''+text
    document.getElementById('getTime').innerText=result
    //1s返回
    setTimeout(getTime,1000)
}
window.addEventListener('load',getTime)
//监听事件
//处理两位数